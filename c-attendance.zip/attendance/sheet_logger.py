from attendance.students import students
import pytz
from datetime import datetime
import requests

SHEET_BEST_URL = "https://api.sheetbest.com/sheets/baa425e0-69fe-41d1-a8f1-15a1b84f4f5e"

def normalize_name(name):
    return name.strip().lower()

def log_attendance(name, usn, period, verbose=True):
    ist = pytz.timezone('Asia/Kolkata')
    now = datetime.now(ist)
    date = now.strftime("%d-%m-%Y")
    time_str = now.strftime("%H:%M:%S")
    day = now.strftime("%A")

    data = {
        "USN": usn,
        "Name": name,
        "Time": time_str,
        "Date": date,
        "Day": day,
        "Period": f"P{period}",
        "Status": "Present"
    }

    response = requests.post(SHEET_BEST_URL, json=data)
    if response.status_code == 200:
        if verbose:
            print(f"[✅ Present Logged] {name} for P{period}")
        return True
    else:
        if verbose:
            print(f"[❌ ERROR] {response.status_code} - {response.text}")
        return False

def fetch_logged_attendance(date, period):
    """
    Fetch all attendance records from the Sheet for given date and period.
    Returns a set of normalized student names marked Present.
    """
    try:
        response = requests.get(SHEET_BEST_URL)
        response.raise_for_status()
        all_records = response.json()

        print("[DEBUG] Fetched records from Sheet:")
        for rec in all_records:
            print(rec)  # Debug print each record

        present_students = set()
        period_str = f"P{period}"

        for record in all_records:
            record_date = record.get("Date", "").strip()
            record_period = record.get("Period", "").strip()
            record_status = record.get("Status", "").strip()
            record_name = record.get("Name", "")

            if (record_date == date and 
                record_period == period_str and 
                record_status.lower() == "present"):
                present_students.add(normalize_name(record_name))

        return present_students

    except requests.RequestException as e:
        print(f"[❌ ERROR] Failed to fetch attendance data: {e}")
        return set()

def log_absentees(period, verbose=True):
    ist = pytz.timezone('Asia/Kolkata')
    now = datetime.now(ist)
    date = now.strftime("%d-%m-%Y")

    present_students = fetch_logged_attendance(date, period)
    if verbose:
        print(f"[ℹ️] Present students fetched from sheet: {present_students}")

    for student in students:
        name = student["name"]
        usn = student["usn"]

        if normalize_name(name) not in present_students:
            # Not present, so log as absent
            data = {
                "USN": usn,
                "Name": name,
                "Time": now.strftime("%H:%M:%S"),
                "Date": date,
                "Day": now.strftime("%A"),
                "Period": f"P{period}",
                "Status": "Absent"
            }

            response = requests.post(SHEET_BEST_URL, json=data)
            if response.status_code == 200:
                if verbose:
                    print(f"[🟥 Absent Logged] {name}")
            else:
                if verbose:
                    print(f"[❌ ERROR] {response.status_code} - {response.text}")
