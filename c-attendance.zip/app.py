from flask import Flask, render_template, Response, request, redirect, url_for, flash
import cv2
from recognition.detector import FaceRecognizer
from attendance.sheet_logger import log_absentees
import requests
import webbrowser
import threading
import time
import smtplib
from email.message import EmailMessage
from flask import request
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from flask import request
import io
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter
from email.message import EmailMessage
import smtplib
import requests
from recognition.detector import FaceRecognizer

import threading
import time
import cv2

# Global variables (declare at top of app.py if not already)
latest_frame = None
processed_frame = None
lock = threading.Lock()
session_active = False

from flask import Flask, render_template, request, redirect, url_for, flash
import threading

latest_frame = None
processed_frame = None
lock = threading.Lock()


app = Flask(__name__)
app.secret_key = "supersecret"  


recognizer = FaceRecognizer()
camera = cv2.VideoCapture(0)

selected_period = "1"
session_active = False

@app.route('/', methods=['GET', 'POST'])
def index():
    global selected_period, session_active
    if request.method == 'POST':
        selected_period = request.form.get("period", "1")
        session_active = True  # Start new webcam session
    return render_template('index.html', selected_period=selected_period)

def open_browser():
    time.sleep(1)  # Wait a moment for Flask to start
    webbrowser.open_new("http://127.0.0.1:5000/")

def background_face_recognition():
    global latest_frame, processed_frame, lock, session_active

    is_processing = False  # Flag to avoid overlap

    while session_active:
        if is_processing:
            time.sleep(0.1)
            continue

        with lock:
            if latest_frame is None:
                continue
            frame = latest_frame.copy()

        is_processing = True

        # Resize frame for faster processing (FaceNet input is 160x160)
        small_frame = cv2.resize(frame, (160, 160))
        result = recognizer.recognize_faces(frame, period=selected_period)

        with lock:
            processed_frame = result
        is_processing = False

        time.sleep(1.5)  # Slow down recognition



def generate_frames():
    global latest_frame, processed_frame, lock, session_active

    camera = cv2.VideoCapture(0)
    camera.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
    camera.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)

    def background_recognition():
        global latest_frame, processed_frame
        while session_active:
            with lock:
                if latest_frame is not None:
                    frame_copy = latest_frame.copy()
                    processed = recognizer.recognize_faces(frame_copy, period=selected_period)
                    processed_frame = processed
            time.sleep(2)  # Run recognition every 2 seconds

    threading.Thread(target=background_recognition, daemon=True).start()

    while session_active:
        success, frame = camera.read()
        if not success:
            break

        with lock:
            latest_frame = frame.copy()
            display = processed_frame if processed_frame is not None else frame

        ret, buffer = cv2.imencode('.jpg', display)
        frame = buffer.tobytes()

        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')

        time.sleep(0.01)

    camera.release()



@app.route('/video')
def video():
    return Response(generate_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/end_session', methods=['POST'])
def end_session():
    global session_active
    period = request.form.get("period", "1")
    log_absentees(period)
    session_active = False  # Stop webcam feed
    flash(f"✅ Absentees logged for Period P{period}")
    return redirect(url_for('index'))

@app.route('/dashboard')
def dashboard():
    SHEET_URL = "https://api.sheetbest.com/sheets/baa425e0-69fe-41d1-a8f1-15a1b84f4f5e"

    name_filter = request.args.get('name', '').strip().lower()
    date_filter = request.args.get('date', '').strip()
    period_filter = request.args.get('period', '').strip()

    try:
        response = requests.get(SHEET_URL)
        records = response.json() if response.status_code == 200 else []
    except Exception as e:
        print(f"[ERROR] Failed to fetch sheet: {e}")
        records = []


    if name_filter:
        records = [r for r in records if name_filter in r["Name"].lower()]
    if date_filter:
        records = [r for r in records if r["Date"] == date_filter]
    if period_filter:
        records = [r for r in records if r["Period"].upper() == f"P{period_filter}"]

     # ⬇️ Calculate stats AFTER filters
    total_logs = len(records)
    present_count = sum(1 for r in records if r["Status"].lower() == "present")
    absent_count = sum(1 for r in records if r["Status"].lower() == "absent")    

    return render_template("dashboard.html",
    records=records,
    total_logs=total_logs,
    present_count=present_count,
    absent_count=absent_count,
    name_filter=name_filter,
    date_filter=date_filter,
    period_filter=period_filter
)


@app.route("/download_csv")
def download_csv():
    import csv
    from io import StringIO
    from flask import Response, request

    SHEET_URL = "https://api.sheetbest.com/sheets/baa425e0-69fe-41d1-a8f1-15a1b84f4f5e"

    name_filter = request.args.get("name", "").strip().lower()
    date_filter = request.args.get("date", "").strip()
    period_filter = request.args.get("period", "").strip()

    # Fetch from sheet
    try:
        response = requests.get(SHEET_URL)
        records = response.json() if response.status_code == 200 else []
    except:
        records = []

    # Apply filters
    if name_filter:
        records = [r for r in records if name_filter in r["Name"].lower()]
    if date_filter:
        records = [r for r in records if r["Date"] == date_filter]
    if period_filter:
        records = [r for r in records if r["Period"].upper() == f"P{period_filter}"]

    # Generate CSV
    si = StringIO()
    writer = csv.DictWriter(si, fieldnames=["USN", "Name", "Date", "Day", "Period", "Time", "Status"])
    writer.writeheader()
    writer.writerows(records)

    output = si.getvalue()
    return Response(
        output,
        mimetype="text/csv",
        headers={"Content-Disposition": "attachment;filename=attendance.csv"}
    )


@app.route("/send_email", methods=["POST"])
def send_email():
    # 1. Fetch data
    sheet_url = "https://api.sheetbest.com/sheets/baa425e0-69fe-41d1-a8f1-15a1b84f4f5e"
    response = requests.get(sheet_url)
    data = response.json()

    # 2. Get filters from form
    name = request.form.get("name")
    date = request.form.get("date")
    period = request.form.get("period")

    # 3. Apply filters
    filtered_data = data
    if name:
        filtered_data = [r for r in filtered_data if r["Name"].lower() == name.lower()]
    if date:
        filtered_data = [r for r in filtered_data if r["Date"] == date]
    if period:
        period = f"P{period}" if not period.upper().startswith("P") else period
        filtered_data = [r for r in filtered_data if r["Period"].upper() == period]

    # 4. Prepare PDF content in memory
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=letter)
    elements = []

    # Table data: header + rows
    if not filtered_data:
        table_data = [["No records found for the selected filters."]]
    else:
        table_data = [["USN", "Name", "Date", "Period", "Time", "Status"]]
        for rec in filtered_data:
            table_data.append([
                rec["USN"],
                rec["Name"],
                rec["Date"],
                rec["Period"],
                rec["Time"],
                rec["Status"]
            ])

    # Table styling
    table = Table(table_data, colWidths=[70, 120, 80, 50, 60, 60])
    table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.black),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 10),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 8),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
    ]))

    elements.append(table)
    doc.build(elements)
    buffer.seek(0)

    # 5. Compose and send email
    msg = EmailMessage()
    msg["Subject"] = "Filtered Attendance Report"
    msg["From"] = "bhuvanshetty1904@gmail.com"
    msg["To"] = "bhuvandinku1910@gmail.com"
    msg.set_content("Hi Faculty,\n\nPlease find the filtered attendance report attached.\n\nRegards,\nSmart Attendance System")

    msg.add_attachment(buffer.read(), maintype="application", subtype="pdf", filename="attendance_report.pdf")

    try:
        with smtplib.SMTP_SSL("smtp.gmail.com", 465) as smtp:
            smtp.login("bhuvanshetty1904@gmail.com", "yoix zmsx rpfd ampy")
            smtp.send_message(msg)
        flash("✅ Email sent successfully!", "success")
        return redirect(url_for("dashboard"))
    except Exception as e:
        return f"❌ Failed to send email: {e}"



if __name__ == "__main__":
    import os
    if os.environ.get("WERKZEUG_RUN_MAIN") == "true":
        # Only run browser on the real main thread
        print("\n🎯 Your Flask app is running!")
        print("📸 Webcam Attendance: http://127.0.0.1:5000/")
        print("📊 Attendance Dashboard: http://127.0.0.1:5000/dashboard\n")

        threading.Thread(target=open_browser).start()

    app.run(debug=True)


