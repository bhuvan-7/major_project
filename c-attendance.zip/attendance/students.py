# attendance/students.py

students = [
    {"name": "Aamir Khan", "usn": "4MH22CA001"},
    {"name": "Aishwarya Rai", "usn": "4MH22CA002"},
    {"name": "Bill Gates", "usn": "4MH22CA003"},
    {"name": "Deepika Padukone", "usn": "4MH22CA004"},
    {"name": "Elon Musk", "usn": "4MH22CA005"},
    {"name": "Mark Zuckerberg", "usn": "4MH22CA006"},
    {"name": "Mukesh Ambani", "usn": "4MH22CA007"},
    {"name": "Narendra Modi", "usn": "4MH22CA008"},
    {"name": "Priyanka Chopra", "usn": "4MH22CA009"},
    {"name": "Shahrukh Khan", "usn": "4MH22CA010"}
]
