import cv2
import numpy as np
from keras_facenet import FaceNet
from sklearn.svm import SVC
from sklearn.preprocessing import LabelEncoder
import pickle
import os
from datetime import datetime
import requests

class FaceRecognizer:
    def __init__(self):
        self.embedder = FaceNet()
        base_path = os.path.dirname(os.path.abspath(__file__))

        # Load classifier and label encoder
        with open(os.path.join(base_path, "classifier.pkl"), "rb") as f:
            self.classifier = pickle.load(f)

        with open(os.path.join(base_path, "label_encoder.pkl"), "rb") as f:
            self.encoder = pickle.load(f)

        # Load face detector
        self.face_cascade = cv2.CascadeClassifier(
            cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
        )

        # Full name to USN mapping
        self.name_to_usn = {
            "Aamir Khan": "4MH22CA001",
            "Aishwarya Rai": "4MH22CA002",
            "Bill Gates": "4MH22CA003",
            "Deepika Padukone": "4MH22CA004",
            "Elon Musk": "4MH22CA005",
            "Mark Zuckerberg": "4MH22CA006",
            "Mukesh Ambani": "4MH22CA007",
            "Narendra Modi": "4MH22CA008",
            "Priyanka Chopra": "4MH22CA009",
            "Shahrukh Khan": "4MH22CA010"
        }

        self.logged_names = set()  # Reset at the start of session

    def recognize_faces(self, frame, period="1"):
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = self.face_cascade.detectMultiScale(gray, 1.3, 5)

        for (x, y, w, h) in faces:
            face = frame[y:y+h, x:x+w]
            face = cv2.resize(face, (160, 160))
            face_rgb = cv2.cvtColor(face, cv2.COLOR_BGR2RGB)

            embedding = self.embedder.embeddings([face_rgb])[0]
            prediction = self.classifier.predict([embedding])[0]
            prob = self.classifier.predict_proba([embedding])[0]
            conf = np.max(prob)

            name = self.encoder.inverse_transform([prediction])[0] if conf >= 0.7 else "Unknown"

            color = (0, 255, 0) if name != "Unknown" else (0, 0, 255)
            cv2.rectangle(frame, (x, y), (x+w, y+h), color, 2)
            cv2.putText(frame, name, (x, y-10), cv2.FONT_HERSHEY_SIMPLEX, 0.8, color, 2)

            if name != "Unknown" and name not in self.logged_names:
                self.log_attendance(name, period)
                self.logged_names.add(name)

        return frame

    def log_attendance(self, name, period):
        now = datetime.now()
        date = now.strftime("%d-%m-%Y")
        day = now.strftime("%A")
        time_str = now.strftime("%H:%M:%S")

        usn = self.name_to_usn.get(name, "N/A")

        data = {
            "USN": usn,
            "Name": name,
            "Date": date,
            "Day": day,
            "Period": f"P{period}",
            "Time": time_str,
            "Status": "Present"
        }

        SHEET_URL = "https://api.sheetbest.com/sheets/baa425e0-69fe-41d1-a8f1-15a1b84f4f5e"

        try:
            response = requests.post(SHEET_URL, json=data)
            if response.status_code == 200:
                print(f"✅ Logged: {name} - {usn}")
            else:
                print(f"[ERROR] Failed to log {name}: {response.status_code}")
        except Exception as e:
            print(f"[ERROR] Exception while logging attendance: {e}")
